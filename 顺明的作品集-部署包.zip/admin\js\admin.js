/**
 * Admin Panel JavaScript
 * Handles all admin functionality including CRUD operations
 */

(function() {
    'use strict';

    // ========================================
    // State
    // ========================================
    let portfolioData = JSON.parse(JSON.stringify(PORTFOLIO_DATA));
    let editingId = null;
    let editingCategory = null;
    let coverFile = null;
    let imageFiles = [];

    // ========================================
    // Initialize
    // ========================================
    function init() {
        loadFromStorage();
        renderAllCollections();
        updateStats();
        setupEventListeners();
    }

    // ========================================
    // Storage
    // ========================================
    function loadFromStorage() {
        const saved = localStorage.getItem('portfolioData');
        if (saved) {
            try {
                portfolioData = JSON.parse(saved);
            } catch (e) {
                console.error('Failed to load saved data:', e);
            }
        }
    }

    function saveToStorage() {
        localStorage.setItem('portfolioData', JSON.stringify(portfolioData));
        // Also update the global PORTFOLIO_DATA for the main page
        if (typeof PORTFOLIO_DATA !== 'undefined') {
            Object.assign(PORTFOLIO_DATA, portfolioData);
        }
    }

    // ========================================
    // Stats
    // ========================================
    function updateStats() {
        const photoCount = portfolioData.photography ? portfolioData.photography.length : 0;
        const ecomCount = portfolioData.ecommerce ? portfolioData.ecommerce.length : 0;
        const typeCount = portfolioData.typesetting ? portfolioData.typesetting.length : 0;
        
        let totalImages = 0;
        ['photography', 'ecommerce', 'typesetting'].forEach(cat => {
            if (portfolioData[cat]) {
                portfolioData[cat].forEach(item => {
                    totalImages += item.images ? item.images.length : 0;
                });
            }
        });

        document.getElementById('photo-count').textContent = photoCount;
        document.getElementById('ecom-count').textContent = ecomCount;
        document.getElementById('type-count').textContent = typeCount;
        document.getElementById('total-images').textContent = totalImages;
    }

    // ========================================
    // Render Collections
    // ========================================
    function renderAllCollections() {
        renderCollections('photography');
        renderCollections('ecommerce');
        renderCollections('typesetting');
    }

    function renderCollections(category) {
        const container = document.getElementById(`${category}-collections`);
        if (!container) return;

        const items = portfolioData[category] || [];
        
        if (items.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                        <circle cx="8.5" cy="8.5" r="1.5"/>
                        <polyline points="21 15 16 10 5 21"/>
                    </svg>
                    <p>暂无作品，点击上方按钮添加</p>
                </div>
            `;
            return;
        }

        container.innerHTML = items.map(item => `
            <div class="collection-admin-card" data-id="${item.id}">
                <div class="collection-cover">
                    ${item.cover 
                        ? `<img src="${item.cover}" alt="${item.title}" loading="lazy">`
                        : `<div class="collection-cover-placeholder">
                            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                                <circle cx="8.5" cy="8.5" r="1.5"/>
                                <polyline points="21 15 16 10 5 21"/>
                            </svg>
                           </div>`
                    }
                </div>
                <div class="collection-card-body">
                    <h3 class="collection-card-title">${item.title}</h3>
                    <p class="collection-card-meta">${item.images ? item.images.length : 0} 张图片 · ${getSizeLabel(item.size)}</p>
                    <div class="collection-card-actions">
                        <button class="edit-btn" onclick="openEditModal('${category}', '${item.id}')">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                            </svg>
                            编辑
                        </button>
                        <button class="delete-btn" onclick="deleteCollection('${category}', '${item.id}')">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="3 6 5 6 21 6"/>
                                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>
                            </svg>
                            删除
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    }

    function getSizeLabel(size) {
        const labels = { normal: '标准', medium: '中等', large: '大' };
        return labels[size] || '标准';
    }

    // ========================================
    // Modal Management
    // ========================================
    window.openAddModal = function(category) {
        editingId = null;
        editingCategory = category;
        coverFile = null;
        imageFiles = [];
        
        document.getElementById('modalTitle').textContent = '添加作品集';
        document.getElementById('collectionId').value = '';
        document.getElementById('collectionCategory').value = category;
        document.getElementById('collectionTitle').value = '';
        document.getElementById('collectionSize').value = 'normal';
        document.getElementById('coverPreview').classList.add('hidden');
        document.querySelector('.upload-placeholder').style.display = 'flex';
        document.getElementById('imagesPreviewGrid').innerHTML = '';
        
        document.getElementById('modalOverlay').classList.add('active');
    };

    window.openEditModal = function(category, id) {
        const item = portfolioData[category].find(i => i.id === id);
        if (!item) return;
        
        editingId = id;
        editingCategory = category;
        coverFile = null;
        imageFiles = [];
        
        document.getElementById('modalTitle').textContent = '编辑作品集';
        document.getElementById('collectionId').value = id;
        document.getElementById('collectionCategory').value = category;
        document.getElementById('collectionTitle').value = item.title;
        document.getElementById('collectionSize').value = item.size || 'normal';
        
        // Show cover preview
        if (item.cover) {
            const preview = document.getElementById('coverPreview');
            preview.src = item.cover;
            preview.classList.remove('hidden');
            document.querySelector('.upload-placeholder').style.display = 'none';
        }
        
        // Show images preview
        const grid = document.getElementById('imagesPreviewGrid');
        grid.innerHTML = '';
        if (item.images) {
            item.images.forEach((img, index) => {
                addImagePreview(img.url, index, true);
            });
        }
        
        document.getElementById('modalOverlay').classList.add('active');
    };

    window.closeModal = function() {
        document.getElementById('modalOverlay').classList.remove('active');
        editingId = null;
        editingCategory = null;
        coverFile = null;
        imageFiles = [];
    };

    // ========================================
    // Image Upload Handling
    // ========================================
    function addImagePreview(src, index, isExisting = false) {
        const grid = document.getElementById('imagesPreviewGrid');
        const item = document.createElement('div');
        item.className = 'preview-item';
        item.dataset.index = index;
        item.dataset.existing = isExisting;
        
        item.innerHTML = `
            <img src="${src}" alt="Preview ${index + 1}">
            <button class="remove-img" onclick="removeImage(${index}, ${isExisting})" title="删除">×</button>
        `;
        
        grid.appendChild(item);
    }

    window.removeImage = function(index, isExisting) {
        if (isExisting && editingId) {
            const item = portfolioData[editingCategory].find(i => i.id === editingId);
            if (item && item.images) {
                item.images.splice(index, 1);
            }
        } else {
            imageFiles.splice(index, 1);
        }
        
        // Re-render previews
        const grid = document.getElementById('imagesPreviewGrid');
        const items = grid.querySelectorAll('.preview-item');
        items[index].remove();
    };

    // ========================================
    // Form Submission
    // ========================================
    function handleFormSubmit(e) {
        e.preventDefault();
        
        const title = document.getElementById('collectionTitle').value.trim();
        const category = document.getElementById('collectionCategory').value;
        const size = document.getElementById('collectionSize').value;
        
        if (!title) {
            showToast('请输入作品集名称', 'error');
            return;
        }

        if (editingId) {
            // Update existing
            const item = portfolioData[category].find(i => i.id === editingId);
            if (item) {
                item.title = title;
                item.size = size;
                
                if (coverFile) {
                    item.cover = URL.createObjectURL(coverFile);
                }
                
                if (imageFiles.length > 0) {
                    const newImages = imageFiles.map(file => ({
                        url: URL.createObjectURL(file),
                        color: '#c9a962'
                    }));
                    item.images = [...(item.images || []), ...newImages];
                }
            }
            showToast('作品集已更新', 'success');
        } else {
            // Create new
            const newItem = {
                id: `${category}-${Date.now()}`,
                title,
                size,
                cover: coverFile ? URL.createObjectURL(coverFile) : '',
                images: imageFiles.map(file => ({
                    url: URL.createObjectURL(file),
                    color: '#c9a962'
                }))
            };
            
            if (!portfolioData[category]) {
                portfolioData[category] = [];
            }
            portfolioData[category].push(newItem);
            showToast('作品集已添加', 'success');
        }
        
        saveToStorage();
        renderCollections(category);
        updateStats();
        closeModal();
    }

    // ========================================
    // Delete Collection
    // ========================================
    window.deleteCollection = function(category, id) {
        if (!confirm('确定要删除这个作品集吗？')) return;
        
        portfolioData[category] = portfolioData[category].filter(i => i.id !== id);
        saveToStorage();
        renderCollections(category);
        updateStats();
        showToast('作品集已删除', 'success');
    };

    // ========================================
    // Section Navigation
    // ========================================
    window.showSection = function(sectionId) {
        // Update nav items
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
            if (item.dataset.section === sectionId) {
                item.classList.add('active');
            }
        });
        
        // Update sections
        document.querySelectorAll('.admin-section').forEach(section => {
            section.classList.remove('active');
        });
        
        const target = document.getElementById(`section-${sectionId}`);
        if (target) {
            target.classList.add('active');
        }
    };

    // ========================================
    // Toast Notification
    // ========================================
    function showToast(message, type = 'default') {
        const toast = document.getElementById('toast');
        toast.querySelector('.toast-message').textContent = message;
        toast.className = `toast ${type}`;
        
        requestAnimationFrame(() => {
            toast.classList.add('show');
        });
        
        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }

    // ========================================
    // Event Listeners
    // ========================================
    function setupEventListeners() {
        // Nav items
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', () => {
                showSection(item.dataset.section);
            });
        });
        
        // Form submission
        document.getElementById('collectionForm').addEventListener('submit', handleFormSubmit);
        
        // Cover image upload
        document.getElementById('coverInput').addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (!file) return;
            
            coverFile = file;
            const reader = new FileReader();
            reader.onload = (ev) => {
                const preview = document.getElementById('coverPreview');
                preview.src = ev.target.result;
                preview.classList.remove('hidden');
                document.querySelector('.upload-placeholder').style.display = 'none';
            };
            reader.readAsDataURL(file);
        });
        
        // Multiple images upload
        document.getElementById('imagesInput').addEventListener('change', (e) => {
            const files = Array.from(e.target.files);
            const startIndex = imageFiles.length;
            
            files.forEach((file, i) => {
                imageFiles.push(file);
                const reader = new FileReader();
                reader.onload = (ev) => {
                    addImagePreview(ev.target.result, startIndex + i, false);
                };
                reader.readAsDataURL(file);
            });
        });
        
        // Close modal on backdrop click
        document.getElementById('modalOverlay').addEventListener('click', (e) => {
            if (e.target === document.getElementById('modalOverlay')) {
                closeModal();
            }
        });
        
        // Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                closeModal();
            }
        });
    }

    // Start
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
