@echo off
chcp 65001 >nul
echo ==========================================
echo    顺明的作品集 - 启动器
echo ==========================================
echo.
echo 正在启动网站...
echo.

REM 获取当前目录
cd /d "%~dp0"

REM 使用默认浏览器打开
start "" "index.html"

echo 网站已在浏览器中打开！
echo.
echo 如果无法打开，请手动复制以下路径到浏览器地址栏：
echo %CD%\index.html
echo.
pause
