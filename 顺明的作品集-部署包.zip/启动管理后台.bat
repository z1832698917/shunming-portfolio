@echo off
chcp 65001 >nul
echo ==========================================
echo    顺明的作品集 - 管理后台启动器
echo ==========================================
echo.
echo 正在打开管理后台...
echo.

cd /d "%~dp0"
start "" "admin\index.html"

echo 管理后台已在浏览器中打开！
echo.
pause
