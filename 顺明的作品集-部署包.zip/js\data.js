/**
 * Portfolio Data Configuration
 * This file contains all the portfolio items data
 * You can easily add, remove, or modify items here
 */

const PORTFOLIO_DATA = {
    // Photography Collection
    photography: [
        {
            id: 'photo-1',
            title: '城市光影',
            cover: 'https://picsum.photos/seed/photo1/800/1000.jpg',
            images: [
                { url: 'https://picsum.photos/seed/photo1a/1200/1600.jpg', color: '#2c3e50' },
                { url: 'https://picsum.photos/seed/photo1b/1200/1600.jpg', color: '#34495e' },
                { url: 'https://picsum.photos/seed/photo1c/1200/1600.jpg', color: '#7f8c8d' },
                { url: 'https://picsum.photos/seed/photo1d/1200/1600.jpg', color: '#95a5a6' }
            ],
            size: 'large'
        },
        {
            id: 'photo-2',
            title: '自然风光',
            cover: 'https://picsum.photos/seed/photo2/800/800.jpg',
            images: [
                { url: 'https://picsum.photos/seed/photo2a/1200/1600.jpg', color: '#27ae60' },
                { url: 'https://picsum.photos/seed/photo2b/1200/1600.jpg', color: '#2ecc71' },
                { url: 'https://picsum.photos/seed/photo2c/1200/1600.jpg', color: '#1abc9c' }
            ],
            size: 'medium'
        },
        {
            id: 'photo-3',
            title: '人像摄影',
            cover: 'https://picsum.photos/seed/photo3/800/1000.jpg',
            images: [
                { url: 'https://picsum.photos/seed/photo3a/1200/1600.jpg', color: '#e74c3c' },
                { url: 'https://picsum.photos/seed/photo3b/1200/1600.jpg', color: '#c0392b' },
                { url: 'https://picsum.photos/seed/photo3c/1200/1600.jpg', color: '#d35400' },
                { url: 'https://picsum.photos/seed/photo3d/1200/1600.jpg', color: '#e67e22' },
                { url: 'https://picsum.photos/seed/photo3e/1200/1600.jpg', color: '#f39c12' }
            ],
            size: 'normal'
        },
        {
            id: 'photo-4',
            title: '建筑几何',
            cover: 'https://picsum.photos/seed/photo4/800/1100.jpg',
            images: [
                { url: 'https://picsum.photos/seed/photo4a/1200/1600.jpg', color: '#9b59b6' },
                { url: 'https://picsum.photos/seed/photo4b/1200/1600.jpg', color: '#8e44ad' },
                { url: 'https://picsum.photos/seed/photo4c/1200/1600.jpg', color: '#2980b9' }
            ],
            size: 'medium'
        },
        {
            id: 'photo-5',
            title: '街头故事',
            cover: 'https://picsum.photos/seed/photo5/800/900.jpg',
            images: [
                { url: 'https://picsum.photos/seed/photo5a/1200/1600.jpg', color: '#16a085' },
                { url: 'https://picsum.photos/seed/photo5b/1200/1600.jpg', color: '#1abc9c' },
                { url: 'https://picsum.photos/seed/photo5c/1200/1600.jpg', color: '#2ecc71' },
                { url: 'https://picsum.photos/seed/photo5d/1200/1600.jpg', color: '#27ae60' }
            ],
            size: 'normal'
        },
        {
            id: 'photo-6',
            title: '夜景迷城',
            cover: 'https://picsum.photos/seed/photo6/800/1200.jpg',
            images: [
                { url: 'https://picsum.photos/seed/photo6a/1200/1600.jpg', color: '#2c3e50' },
                { url: 'https://picsum.photos/seed/photo6b/1200/1600.jpg', color: '#34495e' },
                { url: 'https://picsum.photos/seed/photo6c/1200/1600.jpg', color: '#1a1a2e' }
            ],
            size: 'large'
        }
    ],

    // E-commerce Collection
    ecommerce: [
        {
            id: 'ecom-1',
            title: '品牌视觉设计',
            cover: 'https://picsum.photos/seed/ecom1/800/1000.jpg',
            images: [
                { url: 'https://picsum.photos/seed/ecom1a/1200/1600.jpg', color: '#3498db' },
                { url: 'https://picsum.photos/seed/ecom1b/1200/1600.jpg', color: '#2980b9' },
                { url: 'https://picsum.photos/seed/ecom1c/1200/1600.jpg', color: '#1a5276' },
                { url: 'https://picsum.photos/seed/ecom1d/1200/1600.jpg', color: '#154360' }
            ],
            size: 'large'
        },
        {
            id: 'ecom-2',
            title: '产品摄影',
            cover: 'https://picsum.photos/seed/ecom2/800/850.jpg',
            images: [
                { url: 'https://picsum.photos/seed/ecom2a/1200/1600.jpg', color: '#f1c40f' },
                { url: 'https://picsum.photos/seed/ecom2b/1200/1600.jpg', color: '#f39c12' },
                { url: 'https://picsum.photos/seed/ecom2c/1200/1600.jpg', color: '#d35400' }
            ],
            size: 'medium'
        },
        {
            id: 'ecom-3',
            title: '店铺装修',
            cover: 'https://picsum.photos/seed/ecom3/800/1050.jpg',
            images: [
                { url: 'https://picsum.photos/seed/ecom3a/1200/1600.jpg', color: '#e74c3c' },
                { url: 'https://picsum.photos/seed/ecom3b/1200/1600.jpg', color: '#c0392b' },
                { url: 'https://picsum.photos/seed/ecom3c/1200/1600.jpg', color: '#922b21' },
                { url: 'https://picsum.photos/seed/ecom3d/1200/1600.jpg', color: '#b03a2e' },
                { url: 'https://picsum.photos/seed/ecom3e/1200/1600.jpg', color: '#cb4335' }
            ],
            size: 'normal'
        },
        {
            id: 'ecom-4',
            title: '营销海报',
            cover: 'https://picsum.photos/seed/ecom4/800/900.jpg',
            images: [
                { url: 'https://picsum.photos/seed/ecom4a/1200/1600.jpg', color: '#9b59b6' },
                { url: 'https://picsum.photos/seed/ecom4b/1200/1600.jpg', color: '#8e44ad' },
                { url: 'https://picsum.photos/seed/ecom4c/1200/1600.jpg', color: '#6c3483' }
            ],
            size: 'medium'
        },
        {
            id: 'ecom-5',
            title: '详情页设计',
            cover: 'https://picsum.photos/seed/ecom5/800/1100.jpg',
            images: [
                { url: 'https://picsum.photos/seed/ecom5a/1200/1600.jpg', color: '#1abc9c' },
                { url: 'https://picsum.photos/seed/ecom5b/1200/1600.jpg', color: '#16a085' },
                { url: 'https://picsum.photos/seed/ecom5c/1200/1600.jpg', color: '#0e6655' },
                { url: 'https://picsum.photos/seed/ecom5d/1200/1600.jpg', color: '#117a65' }
            ],
            size: 'normal'
        }
    ],

    // Typesetting Collection
    typesetting: [
        {
            id: 'type-1',
            title: '杂志排版',
            cover: 'https://picsum.photos/seed/type1/800/1100.jpg',
            images: [
                { url: 'https://picsum.photos/seed/type1a/1200/1600.jpg', color: '#2c3e50' },
                { url: 'https://picsum.photos/seed/type1b/1200/1600.jpg', color: '#34495e' },
                { url: 'https://picsum.photos/seed/type1c/1200/1600.jpg', color: '#5d6d7e' },
                { url: 'https://picsum.photos/seed/type1d/1200/1600.jpg', color: '#7f8c8d' }
            ],
            size: 'large'
        },
        {
            id: 'type-2',
            title: '书籍设计',
            cover: 'https://picsum.photos/seed/type2/800/950.jpg',
            images: [
                { url: 'https://picsum.photos/seed/type2a/1200/1600.jpg', color: '#c0392b' },
                { url: 'https://picsum.photos/seed/type2b/1200/1600.jpg', color: '#a93226' },
                { url: 'https://picsum.photos/seed/type2c/1200/1600.jpg', color: '#922b21' }
            ],
            size: 'medium'
        },
        {
            id: 'type-3',
            title: '宣传册',
            cover: 'https://picsum.photos/seed/type3/800/1000.jpg',
            images: [
                { url: 'https://picsum.photos/seed/type3a/1200/1600.jpg', color: '#2980b9' },
                { url: 'https://picsum.photos/seed/type3b/1200/1600.jpg', color: '#1f618d' },
                { url: 'https://picsum.photos/seed/type3c/1200/1600.jpg', color: '#154360' },
                { url: 'https://picsum.photos/seed/type3d/1200/1600.jpg', color: '#1a5276' },
                { url: 'https://picsum.photos/seed/type3e/1200/1600.jpg', color: '#21618c' }
            ],
            size: 'normal'
        },
        {
            id: 'type-4',
            title: '海报设计',
            cover: 'https://picsum.photos/seed/type4/800/1200.jpg',
            images: [
                { url: 'https://picsum.photos/seed/type4a/1200/1600.jpg', color: '#8e44ad' },
                { url: 'https://picsum.photos/seed/type4b/1200/1600.jpg', color: '#7d3c98' },
                { url: 'https://picsum.photos/seed/type4c/1200/1600.jpg', color: '#6c3483' }
            ],
            size: 'large'
        },
        {
            id: 'type-5',
            title: '企业画册',
            cover: 'https://picsum.photos/seed/type5/800/900.jpg',
            images: [
                { url: 'https://picsum.photos/seed/type5a/1200/1600.jpg', color: '#27ae60' },
                { url: 'https://picsum.photos/seed/type5b/1200/1600.jpg', color: '#1e8449' },
                { url: 'https://picsum.photos/seed/type5c/1200/1600.jpg', color: '#196f3d' },
                { url: 'https://picsum.photos/seed/type5d/1200/1600.jpg', color: '#145a32' }
            ],
            size: 'medium'
        }
    ]
};

// Export for use in main.js
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PORTFOLIO_DATA;
}
