@echo off
chcp 65001 >nul
echo ==========================================
echo    顺明的作品集 - HTTP服务器启动器
echo ==========================================
echo.

cd /d "%~dp0"

echo 正在启动本地服务器...
echo 访问地址: http://localhost:8080
echo.
echo 按 Ctrl+C 停止服务器
echo.

python -m http.server 8080

pause
