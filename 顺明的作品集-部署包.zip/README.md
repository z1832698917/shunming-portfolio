# 顺明的作品集 - 部署与使用指南

## 项目概述

这是一个震撼人心的交互式作品集网站，具有以下特点：

### 核心功能
- **三大分区**: 摄影、跨境电商作品、排版作品
- **瀑布流布局**: Masonry网格展示作品集
- **动态交互**: 鼠标悬浮时展开作品集图片，图片hover时页面颜色渐变
- **流畅动画**: 自定义光标、平滑过渡、滚动动画
- **管理后台**: 完整的作品集上传和管理系统

### 设计亮点
- **高级美学**: 受Awwwards获奖网站启发的设计
- **色彩提取**: 根据图片颜色动态改变页面色调
- **鼠标追踪**: 动态背景跟随鼠标移动
- **无缝过渡**: 所有交互都有平滑的动画效果
- **响应式设计**: 适配所有设备尺寸

## 项目结构

```
portfolio_project/
├── index.html              # 主展示页
├── css/
│   └── style.css          # 主样式文件
├── js/
│   ├── main.js            # 主交互逻辑
│   └── data.js            # 作品集数据配置
├── admin/
│   ├── index.html         # 管理后台页面
│   ├── css/
│   │   └── admin.css      # 后台样式
│   ├── js/
│   │   └── admin.js       # 后台逻辑
│   └── assets/
├── assets/images/         # 图片存储目录
```

## 部署方式

### 1. 本地开发
1. 在本地环境中运行 `index.html` 即可预览
2. 不需要任何服务器依赖
3. 使用现代浏览器（Chrome、Firefox、Edge）以获得最佳体验

### 2. 静态网站部署
#### GitHub Pages
```bash
# 1. 创建GitHub仓库
git init
git add .
git commit -m "顺明的作品集"
git branch -M main
git remote add origin https://github.com/yourusername/shunming-portfolio.git
git push -u origin main

# 2. 在仓库设置中开启GitHub Pages
# Settings → Pages → Source: main branch
```

#### Netlify
1. 将代码上传到GitHub
2. 在Netlify中连接到GitHub仓库
3. 自动部署完成

#### Vercel
1. 将代码上传到GitHub
2. 在Vercel中导入GitHub仓库
3. 自动部署完成

### 3. 服务器部署
#### Apache/Nginx
```bash
# 将整个 portfolio_project 目录复制到服务器
scp -r portfolio_project user@server:/var/www/html/shunming-portfolio
```

## 数据管理

### 通过管理后台
1. 访问 `admin/index.html`
2. 可以添加、编辑、删除作品集
3. 支持图片上传
4. 所有数据保存在浏览器本地存储中

### 手动修改
如果要手动编辑作品集数据，修改 `js/data.js` 文件：

```javascript
// 示例格式
{
    id: 'photo-1',
    title: '作品集名称',
    cover: 'https://example.com/cover.jpg', // 封面图URL
    images: [
        { url: 'https://example.com/image1.jpg', color: '#3498db' },
        { url: 'https://example.com/image2.jpg', color: '#e74c3c' }
    ],
    size: 'large' // 可选: normal, medium, large
}
```

## 功能配置

### 自定义样式
- **字体**: 修改 `style.css` 中的 Google Fonts 链接
- **颜色**: 修改CSS变量（`:root` 部分）
- **动画速度**: 调整过渡时间变量

### 自定义交互
- **光标**: 可在 `main.js` 的 `initCursor()` 中修改
- **颜色提取**: 可在 `extractDominantColor()` 中修改算法
- **动画**: 可在 `expandCard()` 和 `collapseCard()` 中调整动画时间

## 浏览器兼容性

### 推荐浏览器
- Chrome 85+
- Firefox 80+
- Safari 14+
- Edge 85+

### 功能支持
- **动态背景**: 需要支持 CSS 自定义属性
- **光标隐藏**: 需要支持 `pointer-events`
- **图片懒加载**: 需要支持 `loading="lazy"`
- **滚动动画**: 需要支持 IntersectionObserver

## 性能优化建议

### 图片优化
1. **使用CDN**: 建议将图片上传到CDN服务
2. **压缩图片**: 保持图片尺寸适中（最大1200x1600）
3. **懒加载**: 所有图片已启用懒加载
4. **WebP格式**: 使用WebP格式图片以减少体积

### 代码优化
1. **减少HTTP请求**: 合并CSS/JS文件
2. **Gzip压缩**: 服务器开启Gzip压缩
3. **缓存策略**: 设置静态资源缓存
4. **CDN加速**: 使用CDN分发CSS/JS文件

## SEO建议

1. **元标签**: 已包含基本SEO元标签
2. **语义化HTML**: 使用适当的语义标签
3. **图片alt**: 为所有图片添加alt描述
4. **响应式**: 移动设备友好设计

## 扩展开发

### 添加新分类
1. 在 `data.js` 中添加新的分类数组
2. 在HTML中添加对应的section
3. 在JS中添加对应的网格渲染

### 集成API
如果需要后端API支持，可扩展：
1. **图片上传**: 连接到云存储API
2. **用户认证**: 添加登录系统
3. **数据库**: 连接到MongoDB或MySQL

### 添加功能
1. **视频支持**: 修改 `expanded-image` 支持视频元素
2. **滤镜效果**: 在CSS中添加滤镜效果
3. **分享功能**: 添加社交媒体分享按钮
4. **评论系统**: 集成评论功能

## 维护与更新

### 定期维护
1. **更新图片**: 定期更新作品集内容
2. **测试功能**: 定期测试所有交互功能
3. **优化性能**: 监控网站性能指标
4. **安全检查**: 确保所有脚本安全

### 版本控制
建议使用Git进行版本控制，定期提交更新。

## 技术支持

### 常见问题
1. **图片不显示**: 检查图片URL是否正确
2. **动画卡顿**: 检查浏览器版本和设备性能
3. **上传失败**: 检查浏览器存储权限
4. **布局错乱**: 检查浏览器兼容性

### 调试工具
- **Console**: 查看JS错误和警告
- **Network**: 检查资源加载情况
- **Performance**: 监控动画性能

## 联系方式

如有问题或需要技术支持，请联系项目开发者。

---

**最后更新**: 2026年3月25日  
**版本**: 1.0.0  
**作者**: 顺明的作品集团队
